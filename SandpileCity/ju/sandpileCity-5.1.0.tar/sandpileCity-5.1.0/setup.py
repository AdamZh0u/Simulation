from distutils.core import setup  
setup(name="sandpileCity", version="5.1.0",py_modules=['sandpileCity.classCity','sandpileCity.classIndexCoor', 'sandpileCity.main']) 